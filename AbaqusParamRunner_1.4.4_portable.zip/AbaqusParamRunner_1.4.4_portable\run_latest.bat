@echo off
cd /d "%~dp0versions\v1.4.4"
call run.bat
