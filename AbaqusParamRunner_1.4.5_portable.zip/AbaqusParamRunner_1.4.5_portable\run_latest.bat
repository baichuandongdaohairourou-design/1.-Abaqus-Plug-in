@echo off
cd /d "%~dp0versions\v1.4.5"
call run.bat
