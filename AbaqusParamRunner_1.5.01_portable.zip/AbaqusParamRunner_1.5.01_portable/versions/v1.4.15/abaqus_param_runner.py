# -*- coding: utf-8 -*-
"""A small first-version GUI for running Abaqus with a Fortran subroutine."""

from __future__ import annotations

import os
import queue
import json
import shutil
import csv
import subprocess
import threading
import time
import itertools
import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from html import escape
from pathlib import Path
from tkinter import (
    BOTH,
    END,
    LEFT,
    RIGHT,
    W,
    BooleanVar,
    Button,
    Checkbutton,
    Entry,
    Frame,
    Label,
    LabelFrame,
    Canvas,
    OptionMenu,
    Scrollbar,
    StringVar,
    Tk,
    Toplevel,
    filedialog,
    messagebox,
)
from tkinter.scrolledtext import ScrolledText


APP_TITLE = "Abaqus Param Runner 1.4.15"
FORTRAN_EXTS = {".for", ".f", ".f90", ".f95", ".f77"}
INP_EXTS = {".inp"}
CONFIG_FILE = Path(__file__).with_name("runner_config.json")
DEFAULT_ABAQUS_COMMANDS = [
    r"D:\ABAQUSAPP\abaqus.bat",
    r"C:\SIMULIA\Commands\abaqus.bat",
    r"C:\SIMULIA\Commands\abq2024.bat",
    r"C:\SIMULIA\Commands\abq2023.bat",
]
NUMERIC_LITERAL = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[DE][+-]?\d+)?$", re.IGNORECASE)
ASSIGNMENT_LINE = re.compile(
    r"^(?P<prefix>\s*)(?P<name>[A-Za-z][A-Za-z0-9_]*)"
    r"(?P<spacing>\s*=\s*)(?P<value>[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[DE][+-]?\d+)?)"
    r"(?P<suffix>\s*)$",
    re.IGNORECASE,
)
PARAMETER_LINE = re.compile(
    r"^(?P<prefix>\s*PARAMETER\s*\(\s*)(?P<name>[A-Za-z][A-Za-z0-9_]*)"
    r"(?P<spacing>\s*=\s*)(?P<value>[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[DE][+-]?\d+)?)"
    r"(?P<suffix>\s*\)\s*)$",
    re.IGNORECASE,
)
SUBPROGRAM_LINE = re.compile(
    r"^\s*(?:SUBROUTINE|(?:DOUBLE\s+PRECISION\s+)?FUNCTION)\s+(?P<name>[A-Za-z][A-Za-z0-9_]*)",
    re.IGNORECASE,
)


@dataclass
class FortranParameter:
    name: str
    scope: str
    display_name: str
    value_text: str
    line_index: int
    kind: str


@dataclass
class SweepSetting:
    parameter: FortranParameter
    enabled: BooleanVar
    start: StringVar
    end: StringVar
    step: StringVar


@dataclass
class InpParameter:
    key: str
    label: str
    value_text: str


@dataclass
class InpSweepSetting:
    parameter: InpParameter
    enabled: BooleanVar
    start: StringVar
    end: StringVar
    step: StringVar


class AbaqusRunnerApp:
    def __init__(self, root: Tk) -> None:
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("980x720")
        self.root.minsize(860, 620)

        self.fortran_path = StringVar()
        self.inp_path = StringVar()
        self.output_dir = StringVar(value=str(Path.cwd() / "abaqus_runs"))
        self.abaqus_cmd = StringVar(value="abaqus")
        self.job_name = StringVar(value="job_001")
        self.cpus = StringVar(value="1")
        self.precision = StringVar(value="默认")
        self.run_mode = StringVar(value="interactive")
        self.extra_args = StringVar()
        self.ask_before_run = BooleanVar(value=True)
        self.odb_path = StringVar()
        self.odb_step = StringVar(value="Step-1")
        self.odb_instance = StringVar()
        self.odb_element = StringVar()
        self.odb_integration_point = StringVar(value="1")
        self.odb_variable = StringVar(value="SDV14")
        self.auto_export_odb = BooleanVar(value=False)
        self.keep_curve_csv = BooleanVar(value=False)
        self.detected_parameters: list[FortranParameter] = []
        self.sweep_settings: list[SweepSetting] = []
        self.detected_inp_parameters: list[InpParameter] = []
        self.inp_sweep_settings: list[InpSweepSetting] = []
        self._loading_config = False
        self._auto_updating_job_name = False
        self._job_name_is_custom = False

        self.process: subprocess.Popen[str] | None = None
        self.log_queue: queue.Queue[str] = queue.Queue()

        self._load_config()
        self._auto_detect_abaqus()
        self._build_ui()
        self._bind_changes()
        self._try_enable_drag_drop()
        self._poll_log_queue()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self) -> None:
        root_pad = {"padx": 12, "pady": 8}

        title = Label(
            self.root,
            text="Abaqus + Fortran 自动运行",
            font=("Microsoft YaHei UI", 18, "bold"),
            anchor=W,
        )
        title.pack(fill="x", **root_pad)

        files = LabelFrame(self.root, text="输入文件")
        files.pack(fill="x", **root_pad)
        self._path_row(
            files,
            "Fortran 子程序",
            self.fortran_path,
            self._select_fortran,
            self._open_parameter_window,
            0,
        )
        self._path_row(files, "Abaqus inp 文件", self.inp_path, self._select_inp, self._open_inp_parameter_window, 1)
        self._path_row(
            files,
            "结果输出文件夹",
            self.output_dir,
            self._select_output_dir,
            None,
            2,
        )
        Button(files, text="打开", command=self._open_output_dir).grid(row=2, column=3, padx=4, pady=6)

        settings = LabelFrame(self.root, text="Abaqus 命令设置")
        settings.pack(fill="x", **root_pad)

        Label(settings, text="Abaqus 命令").grid(row=0, column=0, sticky=W, padx=8, pady=6)
        Entry(settings, textvariable=self.abaqus_cmd).grid(row=0, column=1, sticky="ew", padx=8, pady=6)
        Button(settings, text="选择命令", command=self._select_abaqus_command).grid(
            row=0, column=2, sticky="ew", padx=4, pady=6
        )
        self._labeled_entry(settings, "Job 名称", self.job_name, 1, 2)
        self._labeled_entry(settings, "CPU 核数", self.cpus, 1, 0)

        Label(settings, text="运行方式").grid(row=2, column=0, sticky=W, padx=8, pady=6)
        OptionMenu(settings, self.run_mode, "interactive", "background").grid(
            row=2, column=1, sticky="ew", padx=8, pady=6
        )

        Label(settings, text="精度").grid(row=2, column=2, sticky=W, padx=8, pady=6)
        OptionMenu(settings, self.precision, "默认", "单精度/off", "显式双精度/explicit", "约束双精度/constraint", "全部双精度/both").grid(
            row=2, column=3, sticky="ew", padx=8, pady=6
        )

        Checkbutton(settings, text="运行前确认命令", variable=self.ask_before_run).grid(
            row=3, column=0, columnspan=2, sticky=W, padx=8, pady=6
        )

        for column in range(4):
            settings.columnconfigure(column, weight=1 if column % 2 else 0)

        curve = LabelFrame(self.root, text="计算完成后自动导出曲线图")
        curve.pack(fill="x", **root_pad)
        Checkbutton(curve, text="自动导出 SVG 曲线图", variable=self.auto_export_odb).grid(
            row=0, column=0, sticky=W, padx=8, pady=6
        )
        Checkbutton(curve, text="同时保留 CSV 数据", variable=self.keep_curve_csv).grid(
            row=0, column=1, sticky=W, padx=8, pady=6
        )
        self._odb_entry_row(curve, "Step", self.odb_step, 1, 0)
        self._odb_entry_row(curve, "Instance", self.odb_instance, 1, 2)
        Button(curve, text="选择Instance", command=self._select_instance_from_inp).grid(
            row=1, column=4, sticky="ew", padx=4, pady=6
        )
        self._odb_entry_row(curve, "单元号", self.odb_element, 2, 0)
        self._odb_entry_row(curve, "积分点", self.odb_integration_point, 2, 2)
        self._odb_entry_row(curve, "变量(可多个)", self.odb_variable, 3, 0)
        Button(curve, text="选择变量", command=self._open_odb_variable_selector).grid(
            row=3, column=2, sticky="ew", padx=4, pady=6
        )
        Label(curve, text="自动导出会使用本次计算生成的 odb；手动导出时仍可在窗口中选择任意 odb。").grid(
            row=4, column=0, columnspan=5, sticky=W, padx=8, pady=6
        )
        curve.columnconfigure(1, weight=1)
        curve.columnconfigure(3, weight=1)

        preview = LabelFrame(self.root, text="命令预览")
        preview.pack(fill="x", **root_pad)
        self.command_text = ScrolledText(preview, height=3, wrap="word")
        self.command_text.pack(fill="x", padx=8, pady=8)
        self.command_text.configure(state="disabled")

        controls = Frame(self.root)
        controls.pack(fill="x", **root_pad)
        Button(controls, text="刷新命令", command=self._refresh_command_preview).pack(side=LEFT, padx=4)
        Button(controls, text="运行批量工况", command=self._run_cases).pack(side=LEFT, padx=4)
        Button(controls, text="导出 ODB 曲线", command=self._open_odb_window).pack(side=LEFT, padx=4)
        Button(controls, text="停止运行", command=self._stop_process).pack(side=LEFT, padx=4)
        Button(controls, text="打开输出文件夹", command=self._open_output_dir).pack(side=RIGHT, padx=4)

        log_frame = LabelFrame(self.root, text="运行日志")
        log_frame.pack(fill=BOTH, expand=True, **root_pad)
        self.log_text = ScrolledText(log_frame, wrap="word")
        self.log_text.pack(fill=BOTH, expand=True, padx=8, pady=8)

        self.status = StringVar(value="就绪")
        Label(self.root, textvariable=self.status, anchor=W).pack(fill="x", padx=12, pady=(0, 8))

        self._refresh_command_preview()

    def _path_row(
        self,
        parent: LabelFrame,
        label: str,
        variable: StringVar,
        select_command,
        detect_command,
        row: int,
    ) -> None:
        Label(parent, text=label).grid(row=row, column=0, sticky=W, padx=8, pady=6)
        Entry(parent, textvariable=variable).grid(row=row, column=1, sticky="ew", padx=8, pady=6)
        Button(parent, text="选择", command=select_command).grid(row=row, column=2, padx=4, pady=6)
        if detect_command is not None:
            Button(parent, text="识别参数", command=detect_command).grid(row=row, column=3, padx=4, pady=6)
        parent.columnconfigure(1, weight=1)

    def _labeled_entry(self, parent: LabelFrame, label: str, variable: StringVar, row: int, column: int) -> None:
        Label(parent, text=label).grid(row=row, column=column, sticky=W, padx=8, pady=6)
        Entry(parent, textvariable=variable).grid(row=row, column=column + 1, sticky="ew", padx=8, pady=6)

    def _bind_changes(self) -> None:
        self.fortran_path.trace_add("write", lambda *_: self._clear_fortran_detection())
        self.fortran_path.trace_add("write", lambda *_: self._maybe_set_job_from_fortran())
        self.job_name.trace_add("write", lambda *_: self._mark_job_name_custom())
        self.inp_path.trace_add("write", lambda *_: self._clear_inp_detection())
        for var in (
            self.fortran_path,
            self.inp_path,
            self.output_dir,
            self.abaqus_cmd,
            self.job_name,
            self.cpus,
            self.precision,
            self.run_mode,
            self.extra_args,
        ):
            var.trace_add("write", lambda *_: self._refresh_command_preview())

    def _clear_fortran_detection(self) -> None:
        self.detected_parameters = []
        self.sweep_settings = []

    def _clear_inp_detection(self) -> None:
        self.detected_inp_parameters = []
        self.inp_sweep_settings = []

    def _load_config(self) -> None:
        if not CONFIG_FILE.exists():
            return
        try:
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception:
            return

        self._loading_config = True
        values = {
            "fortran_path": self.fortran_path,
            "inp_path": self.inp_path,
            "output_dir": self.output_dir,
            "abaqus_cmd": self.abaqus_cmd,
            "job_name": self.job_name,
            "cpus": self.cpus,
            "precision": self.precision,
            "run_mode": self.run_mode,
            "extra_args": self.extra_args,
            "odb_path": self.odb_path,
            "odb_step": self.odb_step,
            "odb_instance": self.odb_instance,
            "odb_element": self.odb_element,
            "odb_integration_point": self.odb_integration_point,
            "odb_variable": self.odb_variable,
        }
        for key, variable in values.items():
            value = data.get(key)
            if isinstance(value, str) and value:
                variable.set(value)
        if isinstance(data.get("ask_before_run"), bool):
            self.ask_before_run.set(data["ask_before_run"])
        if isinstance(data.get("auto_export_odb"), bool):
            self.auto_export_odb.set(data["auto_export_odb"])
        if isinstance(data.get("keep_curve_csv"), bool):
            self.keep_curve_csv.set(data["keep_curve_csv"])
        self._loading_config = False
        self._job_name_is_custom = False

    def _save_config(self) -> None:
        data = {
            "fortran_path": self.fortran_path.get(),
            "inp_path": self.inp_path.get(),
            "output_dir": self.output_dir.get(),
            "abaqus_cmd": self.abaqus_cmd.get(),
            "job_name": self.job_name.get(),
            "cpus": self.cpus.get(),
            "precision": self.precision.get(),
            "run_mode": self.run_mode.get(),
            "extra_args": self.extra_args.get(),
            "odb_path": self.odb_path.get(),
            "odb_step": self.odb_step.get(),
            "odb_instance": self.odb_instance.get(),
            "odb_element": self.odb_element.get(),
            "odb_integration_point": self.odb_integration_point.get(),
            "odb_variable": self.odb_variable.get(),
            "ask_before_run": self.ask_before_run.get(),
            "auto_export_odb": self.auto_export_odb.get(),
            "keep_curve_csv": self.keep_curve_csv.get(),
        }
        try:
            CONFIG_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as exc:
            self._log(f"配置保存失败：{exc}")

    def _auto_detect_abaqus(self) -> None:
        current = self.abaqus_cmd.get().strip().strip('"')
        if current and current != "abaqus" and Path(current).exists():
            return

        found = shutil.which("abaqus")
        if found:
            self.abaqus_cmd.set(found)
            return

        for candidate in DEFAULT_ABAQUS_COMMANDS:
            if Path(candidate).exists():
                self.abaqus_cmd.set(candidate)
                return

    def _try_enable_drag_drop(self) -> None:
        try:
            self.root.tk.call("package", "require", "tkdnd")
        except Exception:
            return

        self.root.tk.call("tkdnd::drop_target", "register", self.root, "DND_Files")
        self.root.tk.call("bind", self.root, "<<Drop>>", self.root.register(self._handle_drop) + " %D")
        self._log("已启用文件拖拽：拖入 .for/.f/.f90 或 .inp 文件会自动填入。")

    def _handle_drop(self, data: str) -> None:
        paths = self.root.tk.splitlist(data)
        for item in paths:
            path = Path(item.strip("{}"))
            suffix = path.suffix.lower()
            if suffix in FORTRAN_EXTS:
                self.fortran_path.set(str(path))
            elif suffix in INP_EXTS:
                self.inp_path.set(str(path))
            else:
                self._log(f"跳过不支持的拖拽文件：{path}")

    def _select_fortran(self) -> None:
        path = filedialog.askopenfilename(
            title="选择 Fortran 子程序",
            filetypes=[("Fortran files", "*.for *.f *.f90 *.f95 *.f77"), ("All files", "*.*")],
        )
        if path:
            self.fortran_path.set(path)
            self.detected_parameters = []
            self.sweep_settings = []

    def _maybe_set_job_from_fortran(self) -> None:
        if self._loading_config or self._job_name_is_custom:
            return
        path_text = self.fortran_path.get().strip().strip('"')
        if not path_text:
            return
        stem = Path(path_text).stem
        if not stem:
            return
        self._auto_updating_job_name = True
        self.job_name.set(stem)
        self._auto_updating_job_name = False

    def _mark_job_name_custom(self) -> None:
        if self._loading_config or self._auto_updating_job_name:
            return
        self._job_name_is_custom = True

    def _select_inp(self) -> None:
        path = filedialog.askopenfilename(
            title="选择 Abaqus inp 文件",
            filetypes=[("Abaqus input", "*.inp"), ("All files", "*.*")],
        )
        if path:
            self.inp_path.set(path)
            self.detected_inp_parameters = []
            self.inp_sweep_settings = []
            self._fill_instance_from_inp(show_message=False, overwrite=False)
            if self.job_name.get() == "job_001":
                self.job_name.set(Path(path).stem)

    def _select_output_dir(self) -> None:
        path = filedialog.askdirectory(title="选择结果输出文件夹")
        if path:
            self.output_dir.set(path)

    def _select_odb(self) -> None:
        path = filedialog.askopenfilename(
            title="选择 Abaqus odb 文件",
            filetypes=[("Abaqus odb", "*.odb"), ("All files", "*.*")],
        )
        if path:
            self.odb_path.set(path)

    def _inp_instance_names(self) -> list[str]:
        path = Path(self.inp_path.get().strip().strip('"'))
        if not path.exists():
            raise ValueError("请先选择有效的 inp 文件。")
        names: list[str] = []
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            stripped = line.strip()
            if stripped.upper().startswith("*INSTANCE"):
                name = self._inp_keyword_option(stripped, "name")
                if name and name not in names:
                    names.append(name)
        return names

    def _fill_instance_from_inp(self, show_message: bool = True, overwrite: bool = True) -> None:
        try:
            names = self._inp_instance_names()
            if not names:
                raise ValueError("inp 文件里没有找到 *Instance, name=...。")
            if overwrite or not self.odb_instance.get().strip():
                self.odb_instance.set(names[0])
            if show_message:
                messagebox.showinfo(APP_TITLE, "已读取 Instance：\n" + "\n".join(names))
        except Exception as exc:
            if show_message:
                messagebox.showerror(APP_TITLE, str(exc))

    def _select_instance_from_inp(self) -> None:
        try:
            names = self._inp_instance_names()
            if not names:
                raise ValueError("inp 文件里没有找到 *Instance, name=...。")
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        window = Toplevel(self.root)
        window.title("选择或输入 Instance")
        window.geometry("420x380")
        window.minsize(360, 300)
        body = Frame(window)
        body.pack(fill=BOTH, expand=True, padx=12, pady=12)
        Label(body, text="从 inp 中读取到这些 Instance：", anchor=W).pack(fill="x", pady=(0, 8))
        for name in names:
            Button(body, text=name, command=lambda value=name: (self.odb_instance.set(value), window.destroy())).pack(
                fill="x", pady=3
            )

        Label(body, text="手动输入 Instance：", anchor=W).pack(fill="x", pady=(16, 6))
        manual_instance = StringVar(value=self.odb_instance.get())
        Entry(body, textvariable=manual_instance).pack(fill="x", pady=(0, 8))

        def apply_manual_instance() -> None:
            value = manual_instance.get().strip()
            if not value:
                messagebox.showerror(APP_TITLE, "Instance 不能为空。", parent=window)
                return
            self.odb_instance.set(value)
            window.destroy()

        buttons = Frame(body)
        buttons.pack(fill="x", pady=(8, 0))
        Button(buttons, text="关闭", command=window.destroy).pack(side=RIGHT, padx=4)
        Button(buttons, text="使用手动输入", command=apply_manual_instance).pack(side=RIGHT, padx=4)

    def _inp_depvar_count(self) -> int:
        path = Path(self.inp_path.get().strip().strip('"'))
        if not path.exists():
            raise ValueError("请先选择有效的 inp 文件。")
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        maximum = 0
        for index, line in enumerate(lines):
            if line.strip().upper().startswith("*DEPVAR"):
                data = self._next_inp_data_line(lines, index)
                if data and data[1] and data[1][0]:
                    try:
                        maximum = max(maximum, int(float(data[1][0])))
                    except ValueError:
                        continue
        return maximum

    def _inp_odb_variables(self) -> list[str]:
        path = Path(self.inp_path.get().strip().strip('"'))
        if not path.exists():
            raise ValueError("请先选择有效的 inp 文件。")
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        depvar_count = self._inp_depvar_count()
        variables: list[str] = []
        index = 0
        while index < len(lines):
            stripped = lines[index].strip()
            upper = stripped.upper()
            if upper.startswith("*ELEMENT OUTPUT"):
                index += 1
                while index < len(lines):
                    candidate = lines[index].strip()
                    if candidate.startswith("*"):
                        break
                    if candidate and not candidate.startswith("**"):
                        for token in candidate.split(","):
                            variable = token.strip().upper()
                            if not variable:
                                continue
                            if variable == "SDV" and depvar_count > 0:
                                for number in range(1, depvar_count + 1):
                                    sdv_name = f"SDV{number}"
                                    if sdv_name not in variables:
                                        variables.append(sdv_name)
                            elif variable not in variables:
                                variables.append(variable)
                    index += 1
                continue
            index += 1
        if not variables and depvar_count > 0:
            variables = [f"SDV{number}" for number in range(1, depvar_count + 1)]
        return variables

    def _open_odb_variable_selector(self) -> None:
        try:
            variables = self._inp_odb_variables()
            if not variables:
                raise ValueError("inp 的 *Element Output 中没有找到可选择的输出变量。")
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        selected = set(self._parse_odb_variables())
        window = Toplevel(self.root)
        window.title("选择 ODB 变量")
        window.geometry("520x520")
        window.minsize(460, 360)

        outer = Frame(window)
        outer.pack(fill=BOTH, expand=True, padx=12, pady=12)
        canvas = Canvas(outer, highlightthickness=0)
        scrollbar = Scrollbar(outer, orient="vertical", command=canvas.yview)
        body = Frame(canvas)
        body.bind("<Configure>", lambda _: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=body, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=LEFT, fill=BOTH, expand=True)
        scrollbar.pack(side=RIGHT, fill="y")

        checks: list[tuple[str, BooleanVar]] = []
        for row, variable in enumerate(variables):
            flag = BooleanVar(value=variable in selected)
            Checkbutton(body, text=variable, variable=flag).grid(row=row, column=0, sticky=W, padx=6, pady=3)
            checks.append((variable, flag))

        buttons = Frame(window)
        buttons.pack(fill="x", padx=12, pady=(0, 12))

        def apply_selection() -> None:
            chosen = [variable for variable, flag in checks if flag.get()]
            if not chosen:
                messagebox.showerror(APP_TITLE, "请至少选择一个变量。")
                return
            self.odb_variable.set(", ".join(chosen))
            window.destroy()

        Button(buttons, text="关闭", command=window.destroy).pack(side=RIGHT, padx=4)
        Button(buttons, text="确定", command=apply_selection).pack(side=RIGHT, padx=4)

    def _select_abaqus_command(self) -> None:
        path = filedialog.askopenfilename(
            title="选择 Abaqus 启动命令",
            filetypes=[
                ("Abaqus command", "abaqus.bat abq*.bat *.bat *.cmd *.exe"),
                ("All files", "*.*"),
            ],
        )
        if path:
            self.abaqus_cmd.set(path)

    def _open_odb_window(self) -> None:
        window = Toplevel(self.root)
        window.title("ODB 曲线导出")
        window.geometry("720x320")
        window.minsize(680, 280)

        body = Frame(window)
        body.pack(fill=BOTH, expand=True, padx=12, pady=12)

        Label(body, text="ODB 文件").grid(row=0, column=0, sticky=W, padx=6, pady=6)
        Entry(body, textvariable=self.odb_path).grid(row=0, column=1, columnspan=3, sticky="ew", padx=6, pady=6)
        Button(body, text="选择", command=self._select_odb).grid(row=0, column=4, padx=6, pady=6)

        self._odb_entry_row(body, "Step", self.odb_step, 1, 0)
        self._odb_entry_row(body, "Instance", self.odb_instance, 1, 2)
        Button(body, text="选择Instance", command=self._select_instance_from_inp).grid(row=1, column=4, padx=6, pady=6)
        self._odb_entry_row(body, "单元号", self.odb_element, 2, 0)
        self._odb_entry_row(body, "积分点", self.odb_integration_point, 2, 2)
        self._odb_entry_row(body, "变量(可多个)", self.odb_variable, 3, 0)
        Button(body, text="选择变量", command=self._open_odb_variable_selector).grid(row=3, column=4, padx=6, pady=6)
        Checkbutton(body, text="同时保留 CSV 数据", variable=self.keep_curve_csv).grid(
            row=4, column=0, columnspan=2, sticky=W, padx=6, pady=6
        )

        hint = Label(
            body,
            text="示例：PART-1-1 / 44 / 1 / SDV14, SDV15, PEEQ",
            anchor=W,
        )
        hint.grid(row=5, column=0, columnspan=5, sticky="ew", padx=6, pady=(10, 6))

        body.columnconfigure(1, weight=1)
        body.columnconfigure(3, weight=1)

        buttons = Frame(window)
        buttons.pack(fill="x", padx=12, pady=(0, 12))
        Button(buttons, text="关闭", command=window.destroy).pack(side=RIGHT, padx=4)
        Button(buttons, text="导出曲线", command=self._export_odb_curve).pack(side=RIGHT, padx=4)

    def _odb_entry_row(self, parent: Frame, label: str, variable: StringVar, row: int, column: int) -> None:
        Label(parent, text=label).grid(row=row, column=column, sticky=W, padx=6, pady=6)
        Entry(parent, textvariable=variable).grid(row=row, column=column + 1, sticky="ew", padx=6, pady=6)

    def _detect_parameters(self) -> list[FortranParameter]:
        source = Path(self.fortran_path.get().strip().strip('"'))
        if not source.exists():
            raise ValueError("请先选择有效的 Fortran 文件。")

        parameters: list[FortranParameter] = []
        lines = source.read_text(encoding="utf-8", errors="replace").splitlines()
        scopes = self._fortran_scopes(lines)
        initialization_zone = self._fortran_initialization_zone(lines, scopes)
        declared_by_scope: dict[str, set[str]] = {}
        for scope in set(scopes):
            declared_by_scope[scope] = set()

        for line, scope in zip(lines, scopes):
            upper = line.upper()
            if "DOUBLE PRECISION" not in upper:
                continue
            declared = upper.split("DOUBLE PRECISION", 1)[1]
            for raw_name in declared.split(","):
                clean = raw_name.strip().split("(", 1)[0]
                if clean:
                    declared_by_scope[scope].add(clean)

        for index, (line, scope) in enumerate(zip(lines, scopes)):
            parameter_match = PARAMETER_LINE.match(line)
            if parameter_match:
                name = parameter_match.group("name")
                value = parameter_match.group("value")
                if NUMERIC_LITERAL.match(value):
                    parameters.append(
                        FortranParameter(
                            name=name,
                            scope=scope,
                            display_name=f"{scope}.{name}",
                            value_text=value,
                            line_index=index,
                            kind="parameter",
                        )
                    )
                continue

            assignment_match = ASSIGNMENT_LINE.match(line)
            if not assignment_match or not initialization_zone[index]:
                continue
            name = assignment_match.group("name")
            value = assignment_match.group("value")
            if name.upper() not in declared_by_scope.get(scope, set()):
                continue
            if not NUMERIC_LITERAL.match(value):
                continue
            parameters.append(
                FortranParameter(
                    name=name,
                    scope=scope,
                    display_name=f"{scope}.{name}",
                    value_text=value,
                    line_index=index,
                    kind="assignment",
                )
            )
        return parameters

    def _fortran_scopes(self, lines: list[str]) -> list[str]:
        scopes: list[str] = []
        current_scope = "GLOBAL"
        for line in lines:
            match = SUBPROGRAM_LINE.match(line)
            if match:
                current_scope = match.group("name").upper()
            scopes.append(current_scope)
        return scopes

    def _fortran_initialization_zone(self, lines: list[str], scopes: list[str]) -> list[bool]:
        zones: list[bool] = []
        active_by_scope: dict[str, bool] = {}
        for line, scope in zip(lines, scopes):
            active = active_by_scope.setdefault(scope, True)
            upper = line.upper().lstrip()
            if upper.startswith(("CALL ", "DO ", "IF ")):
                active = False
                active_by_scope[scope] = False
            zones.append(active)
        return zones

    def _open_parameter_window(self) -> None:
        try:
            self.detected_parameters = self._detect_parameters()
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        if not self.detected_parameters:
            messagebox.showinfo(APP_TITLE, "没有识别到可调参数。")
            return

        if not self.sweep_settings or len(self.sweep_settings) != len(self.detected_parameters):
            self.sweep_settings = [
                SweepSetting(
                    parameter=parameter,
                    enabled=BooleanVar(value=False),
                    start=StringVar(value=self._fortran_to_decimal_text(parameter.value_text)),
                    end=StringVar(value=self._fortran_to_decimal_text(parameter.value_text)),
                    step=StringVar(value="0"),
                )
                for parameter in self.detected_parameters
            ]

        window = Toplevel(self.root)
        window.title("参数扫描设置")
        window.geometry("760x520")
        window.minsize(680, 420)

        outer = Frame(window)
        outer.pack(fill=BOTH, expand=True, padx=12, pady=12)
        canvas = Canvas(outer, highlightthickness=0)
        scrollbar = Scrollbar(outer, orient="vertical", command=canvas.yview)
        body = Frame(canvas)
        body.bind("<Configure>", lambda _: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=body, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=LEFT, fill=BOTH, expand=True)
        scrollbar.pack(side=RIGHT, fill="y")

        headers = ["选择", "变量", "当前值", "起点", "终点", "步长"]
        for column, text in enumerate(headers):
            Label(body, text=text, font=("Microsoft YaHei UI", 10, "bold")).grid(
                row=0, column=column, sticky=W, padx=6, pady=6
            )

        for row, setting in enumerate(self.sweep_settings, start=1):
            Checkbutton(body, variable=setting.enabled).grid(row=row, column=0, padx=6, pady=4)
            Label(body, text=setting.parameter.display_name).grid(row=row, column=1, sticky=W, padx=6, pady=4)
            Label(body, text=setting.parameter.value_text).grid(row=row, column=2, sticky=W, padx=6, pady=4)
            Entry(body, textvariable=setting.start, width=14).grid(row=row, column=3, padx=6, pady=4)
            Entry(body, textvariable=setting.end, width=14).grid(row=row, column=4, padx=6, pady=4)
            Entry(body, textvariable=setting.step, width=14).grid(row=row, column=5, padx=6, pady=4)

        buttons = Frame(window)
        buttons.pack(fill="x", padx=12, pady=(0, 12))
        Button(buttons, text="关闭", command=window.destroy).pack(side=RIGHT, padx=4)
        Button(buttons, text="生成批量工况", command=self._generate_case_files).pack(side=RIGHT, padx=4)

    def _fortran_to_decimal_text(self, value: str) -> str:
        return value.upper().replace("D", "E")

    def _parse_decimal(self, text: str, field_name: str) -> Decimal:
        normalized = text.strip().upper().replace("D", "E")
        try:
            return Decimal(normalized)
        except InvalidOperation as exc:
            raise ValueError(f"{field_name} 不是有效数字：{text}") from exc

    def _selected_sweep_values(self) -> list[tuple[FortranParameter, list[Decimal]]]:
        selected: list[tuple[FortranParameter, list[Decimal]]] = []
        for setting in self.sweep_settings:
            if not setting.enabled.get():
                continue
            start = self._parse_decimal(setting.start.get(), f"{setting.parameter.display_name} 起点")
            end = self._parse_decimal(setting.end.get(), f"{setting.parameter.display_name} 终点")
            step = self._parse_decimal(setting.step.get(), f"{setting.parameter.display_name} 步长")
            values = self._build_sweep_values(setting.parameter.display_name, start, end, step)
            selected.append((setting.parameter, values))
        return selected

    def _build_sweep_values(self, name: str, start: Decimal, end: Decimal, step: Decimal) -> list[Decimal]:
        if step <= 0:
            raise ValueError(f"{name} 的步长必须大于 0。")
        values: list[Decimal] = []
        current = start
        if start <= end:
            while current <= end:
                values.append(current)
                current += step
        else:
            while current >= end:
                values.append(current)
                current -= step
        return values

    def _format_fortran_decimal(self, value: Decimal) -> str:
        text = f"{value:.12E}"
        mantissa, exponent = text.split("E")
        mantissa = mantissa.rstrip("0").rstrip(".")
        if "." not in mantissa:
            mantissa += ".0"
        return f"{mantissa}D{int(exponent):+d}"

    def _replace_fortran_parameter(self, line: str, parameter: FortranParameter, formatted: str) -> str:
        pattern = PARAMETER_LINE if parameter.kind == "parameter" else ASSIGNMENT_LINE
        match = pattern.match(line)
        if not match:
            raise ValueError(f"参数行已变化，无法替换：{parameter.display_name}")
        return (
            f"{match.group('prefix')}{match.group('name')}"
            f"{match.group('spacing')}{formatted}{match.group('suffix')}"
        )

    def _next_inp_data_line(self, lines: list[str], index: int) -> tuple[int, list[str]] | None:
        for data_index in range(index + 1, len(lines)):
            candidate = lines[data_index].strip()
            if not candidate or candidate.startswith("**"):
                continue
            if candidate.startswith("*"):
                return None
            return data_index, [part.strip() for part in lines[data_index].split(",")]
        return None

    def _inp_keyword_option(self, line: str, option: str) -> str | None:
        prefix = option.upper() + "="
        for part in line.split(","):
            text = part.strip()
            if text.upper().startswith(prefix):
                return text.split("=", 1)[1].strip()
        return None

    def _material_parameter_key(self, material: str | None, parameter: str) -> str:
        if material:
            return f"MATERIAL::{material}::{parameter}"
        return parameter

    def _base_inp_key(self, key: str) -> str:
        return key.rsplit("::", 1)[-1]

    def _material_parameter_label(self, material: str | None, title: str, parameter: str) -> str:
        if material:
            return f"{material} - {title} {parameter}"
        return f"{title} {parameter}"

    def _inp_value_for(self, values: dict[str, str], material: str | None, parameter: str) -> str | None:
        material_key = self._material_parameter_key(material, parameter)
        if material_key in values:
            return values[material_key]
        if not material and parameter in values:
            return values[parameter]
        return None

    def _clean_inp_number_text(self, value: str) -> str:
        text = value.strip()
        if re.fullmatch(r"[+-]?(?:\d+|\d+\.)", text):
            return text[:-1] if text.endswith(".") else text
        return text

    def _detect_inp_parameters(self) -> list[InpParameter]:
        source = Path(self.inp_path.get().strip().strip('"'))
        if not source.exists():
            raise ValueError("请先选择有效的 inp 文件。")

        lines = source.read_text(encoding="utf-8", errors="replace").splitlines()
        found: list[InpParameter] = []
        current_material: str | None = None
        for index, line in enumerate(lines):
            stripped = line.strip()
            upper = stripped.upper()
            if upper.startswith("*MATERIAL"):
                current_material = self._inp_keyword_option(stripped, "name") or f"Material@L{index + 1}"
            elif upper == "*INITIAL CONDITIONS, TYPE=TEMPERATURE" and index + 1 < len(lines):
                parts = [part.strip() for part in lines[index + 1].split(",")]
                if len(parts) >= 2 and parts[1]:
                    found.append(InpParameter("TEMP0", "初始温度 TEMP0", self._clean_inp_number_text(parts[1])))
            elif upper.startswith("*DYNAMIC TEMPERATURE-DISPLACEMENT") and index + 1 < len(lines):
                parts = [part.strip() for part in lines[index + 1].split(",")]
                if len(parts) >= 2 and parts[1]:
                    found.append(InpParameter("STEP_TIME", "分析总时间 STEP_TIME", self._clean_inp_number_text(parts[1])))
            elif upper.startswith("*AMPLITUDE") and "NAME=AMP-3" in upper and index + 1 < len(lines):
                parts = [part.strip() for part in lines[index + 1].split(",")]
                if len(parts) >= 4 and parts[2]:
                    found.append(InpParameter("AMP3_END_TIME", "Amp-3 完成时间", self._clean_inp_number_text(parts[2])))
            elif upper.startswith("*BOUNDARY, AMPLITUDE=AMP-3"):
                block = lines[index + 1 : index + 4]
                values: list[str] = []
                for candidate in block:
                    parts = [part.strip() for part in candidate.split(",")]
                    if len(parts) >= 4 and parts[1:3] == ["2", "2"] and parts[3]:
                        values.append(parts[3])
                if len(values) == 1:
                    magnitude = self._clean_inp_number_text(values[0].lstrip("+-"))
                    found.append(InpParameter("DISP_Y", "位移幅值 DISP_Y", magnitude))
            elif upper.startswith("*DEPVAR"):
                data = self._next_inp_data_line(lines, index)
                if data and data[1] and data[1][0]:
                    found.append(
                        InpParameter(
                            self._material_parameter_key(current_material, "DEPVAR"),
                            self._material_parameter_label(current_material, "状态变量数", "DEPVAR"),
                            self._clean_inp_number_text(data[1][0]),
                        )
                    )
            elif upper.startswith("*DENSITY"):
                data = self._next_inp_data_line(lines, index)
                if data and data[1] and data[1][0]:
                    found.append(
                        InpParameter(
                            self._material_parameter_key(current_material, "DENSITY"),
                            self._material_parameter_label(current_material, "密度", "DENSITY"),
                            self._clean_inp_number_text(data[1][0]),
                        )
                    )
            elif upper.startswith("*ELASTIC"):
                data = self._next_inp_data_line(lines, index)
                if data and len(data[1]) >= 2:
                    if data[1][0]:
                        found.append(
                            InpParameter(
                                self._material_parameter_key(current_material, "ELASTIC_E"),
                                self._material_parameter_label(current_material, "杨氏模量", "ELASTIC_E"),
                                self._clean_inp_number_text(data[1][0]),
                            )
                        )
                    if data[1][1]:
                        found.append(
                            InpParameter(
                                self._material_parameter_key(current_material, "ELASTIC_NU"),
                                self._material_parameter_label(current_material, "泊松比", "ELASTIC_NU"),
                                self._clean_inp_number_text(data[1][1]),
                            )
                        )
            elif upper.startswith("*CONDUCTIVITY"):
                data = self._next_inp_data_line(lines, index)
                if data and data[1] and data[1][0]:
                    found.append(
                        InpParameter(
                            self._material_parameter_key(current_material, "CONDUCTIVITY"),
                            self._material_parameter_label(current_material, "导热系数", "CONDUCTIVITY"),
                            self._clean_inp_number_text(data[1][0]),
                        )
                    )
            elif upper.startswith("*SPECIFIC HEAT"):
                data = self._next_inp_data_line(lines, index)
                if data and data[1] and data[1][0]:
                    found.append(
                        InpParameter(
                            self._material_parameter_key(current_material, "SPECIFIC_HEAT"),
                            self._material_parameter_label(current_material, "比热", "SPECIFIC_HEAT"),
                            self._clean_inp_number_text(data[1][0]),
                        )
                    )
        unique: dict[str, InpParameter] = {}
        for item in found:
            unique.setdefault(item.key, item)
        return list(unique.values())

    def _open_inp_parameter_window(self) -> None:
        try:
            self.detected_inp_parameters = self._detect_inp_parameters()
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        if not self.detected_inp_parameters:
            messagebox.showinfo(APP_TITLE, "没有识别到可调 inp 参数。")
            return

        if not self.inp_sweep_settings or len(self.inp_sweep_settings) != len(self.detected_inp_parameters):
            self.inp_sweep_settings = [
                InpSweepSetting(
                    parameter=parameter,
                    enabled=BooleanVar(value=False),
                    start=StringVar(value=parameter.value_text),
                    end=StringVar(value=parameter.value_text),
                    step=StringVar(value="0"),
                )
                for parameter in self.detected_inp_parameters
            ]

        window = Toplevel(self.root)
        window.title("inp 参数扫描设置")
        window.geometry("760x360")
        window.minsize(680, 300)

        outer = Frame(window)
        outer.pack(fill=BOTH, expand=True, padx=12, pady=12)
        canvas = Canvas(outer, highlightthickness=0)
        scrollbar = Scrollbar(outer, orient="vertical", command=canvas.yview)
        body = Frame(canvas)
        body.bind("<Configure>", lambda _: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=body, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=LEFT, fill=BOTH, expand=True)
        scrollbar.pack(side=RIGHT, fill="y")

        headers = ["选择", "参数", "当前值", "起点", "终点", "步长"]
        for column, text in enumerate(headers):
            Label(body, text=text, font=("Microsoft YaHei UI", 10, "bold")).grid(
                row=0, column=column, sticky=W, padx=6, pady=6
            )
        for row, setting in enumerate(self.inp_sweep_settings, start=1):
            Checkbutton(body, variable=setting.enabled).grid(row=row, column=0, padx=6, pady=4)
            Label(body, text=setting.parameter.label).grid(row=row, column=1, sticky=W, padx=6, pady=4)
            Label(body, text=setting.parameter.value_text).grid(row=row, column=2, sticky=W, padx=6, pady=4)
            Entry(body, textvariable=setting.start, width=14).grid(row=row, column=3, padx=6, pady=4)
            Entry(body, textvariable=setting.end, width=14).grid(row=row, column=4, padx=6, pady=4)
            Entry(body, textvariable=setting.step, width=14).grid(row=row, column=5, padx=6, pady=4)
        buttons = Frame(window)
        buttons.pack(fill="x", padx=12, pady=(0, 12))
        Button(buttons, text="关闭", command=window.destroy).pack(side=RIGHT, padx=4)
        Button(buttons, text="生成批量工况", command=self._generate_case_files).pack(side=RIGHT, padx=4)

    def _selected_inp_sweep_values(self) -> list[tuple[InpParameter, list[Decimal]]]:
        selected: list[tuple[InpParameter, list[Decimal]]] = []
        for setting in self.inp_sweep_settings:
            if not setting.enabled.get():
                continue
            start = self._parse_decimal(setting.start.get(), f"{setting.parameter.key} 起点")
            end = self._parse_decimal(setting.end.get(), f"{setting.parameter.key} 终点")
            step = self._parse_decimal(setting.step.get(), f"{setting.parameter.key} 步长")
            values = self._build_sweep_values(setting.parameter.key, start, end, step)
            selected.append((setting.parameter, values))
        return selected

    def _format_inp_decimal(self, value: Decimal) -> str:
        normalized = value.normalize()
        return format(normalized, "f")

    def _format_inp_parameter_value(self, key: str, value: Decimal) -> str:
        if self._base_inp_key(key) == "DEPVAR":
            integral = value.to_integral_value()
            if value != integral or value <= 0:
                raise ValueError("DEPVAR 必须是正整数。")
            return str(int(integral))
        return self._format_inp_decimal(value)

    def _replace_inp_parameters(self, lines: list[str], values: dict[str, str]) -> list[str]:
        updated = list(lines)
        current_material: str | None = None
        for index, line in enumerate(updated):
            stripped = line.strip()
            upper = stripped.upper()
            if upper.startswith("*MATERIAL"):
                current_material = self._inp_keyword_option(stripped, "name") or f"Material@L{index + 1}"
            elif "TEMP0" in values and upper == "*INITIAL CONDITIONS, TYPE=TEMPERATURE":
                parts = [part.strip() for part in updated[index + 1].split(",")]
                parts[1] = values["TEMP0"]
                updated[index + 1] = ", ".join(parts)
            elif "STEP_TIME" in values and upper.startswith("*DYNAMIC TEMPERATURE-DISPLACEMENT"):
                parts = [part.strip() for part in updated[index + 1].split(",")]
                parts[1] = values["STEP_TIME"]
                updated[index + 1] = ", ".join(parts)
            elif "AMP3_END_TIME" in values and upper.startswith("*AMPLITUDE") and "NAME=AMP-3" in upper:
                parts = [part.strip() for part in updated[index + 1].split(",")]
                parts[2] = values["AMP3_END_TIME"]
                updated[index + 1] = ", ".join(parts)
            elif "DISP_Y" in values and upper.startswith("*BOUNDARY, AMPLITUDE=AMP-3"):
                for offset in range(1, 4):
                    if index + offset >= len(updated):
                        break
                    parts = [part.strip() for part in updated[index + offset].split(",")]
                    if len(parts) >= 4 and parts[1:3] == ["2", "2"]:
                        sign = "-" if parts[3].startswith("-") else ""
                        parts[3] = sign + values["DISP_Y"]
                        updated[index + offset] = ", ".join(parts)
            elif self._inp_value_for(values, current_material, "DEPVAR") is not None and upper.startswith("*DEPVAR"):
                depvar_value = self._inp_value_for(values, current_material, "DEPVAR")
                for data_index in range(index + 1, len(updated)):
                    candidate = updated[data_index].strip()
                    if not candidate or candidate.startswith("**"):
                        continue
                    if candidate.startswith("*"):
                        break
                    original = updated[data_index]
                    if "," in original:
                        _, suffix = original.split(",", 1)
                        updated[data_index] = f"{depvar_value},{suffix}"
                    else:
                        updated[data_index] = depvar_value or ""
                    break
            elif self._inp_value_for(values, current_material, "DENSITY") is not None and upper.startswith("*DENSITY"):
                data = self._next_inp_data_line(updated, index)
                if data:
                    data_index, parts = data
                    parts[0] = self._inp_value_for(values, current_material, "DENSITY") or parts[0]
                    updated[data_index] = ", ".join(parts)
            elif (
                self._inp_value_for(values, current_material, "ELASTIC_E") is not None
                or self._inp_value_for(values, current_material, "ELASTIC_NU") is not None
            ) and upper.startswith("*ELASTIC"):
                data = self._next_inp_data_line(updated, index)
                if data:
                    data_index, parts = data
                    while len(parts) < 2:
                        parts.append("")
                    elastic_e = self._inp_value_for(values, current_material, "ELASTIC_E")
                    elastic_nu = self._inp_value_for(values, current_material, "ELASTIC_NU")
                    if elastic_e is not None:
                        parts[0] = elastic_e
                    if elastic_nu is not None:
                        parts[1] = elastic_nu
                    updated[data_index] = ", ".join(parts)
            elif self._inp_value_for(values, current_material, "CONDUCTIVITY") is not None and upper.startswith("*CONDUCTIVITY"):
                data = self._next_inp_data_line(updated, index)
                if data:
                    data_index, parts = data
                    parts[0] = self._inp_value_for(values, current_material, "CONDUCTIVITY") or parts[0]
                    updated[data_index] = ", ".join(parts)
            elif self._inp_value_for(values, current_material, "SPECIFIC_HEAT") is not None and upper.startswith("*SPECIFIC HEAT"):
                data = self._next_inp_data_line(updated, index)
                if data:
                    data_index, parts = data
                    parts[0] = self._inp_value_for(values, current_material, "SPECIFIC_HEAT") or parts[0]
                    updated[data_index] = ", ".join(parts)
        return updated

    def _sweep_root_dir(self) -> Path:
        source = Path(self.fortran_path.get().strip().strip('"'))
        return Path(self.output_dir.get().strip().strip('"')) / f"{source.stem}_sweep"

    def _generate_sweep_files(self) -> list[tuple[Path, dict[str, str]]]:
        try:
            selected = self._selected_sweep_values()
            if not selected:
                raise ValueError("请至少勾选一个要修改的参数。")
            source = Path(self.fortran_path.get().strip().strip('"'))
            lines = source.read_text(encoding="utf-8", errors="replace").splitlines()
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return []

        root = self._sweep_root_dir()
        root.mkdir(parents=True, exist_ok=True)
        generated: list[tuple[Path, dict[str, str]]] = []

        parameter_names = [parameter.display_name for parameter, _ in selected]
        value_lists = [values for _, values in selected]
        for index, combination in enumerate(itertools.product(*value_lists), start=1):
            variant_lines = list(lines)
            value_map: dict[str, str] = {}
            for (parameter, _), value in zip(selected, combination):
                formatted = self._format_fortran_decimal(value)
                original = variant_lines[parameter.line_index]
                variant_lines[parameter.line_index] = self._replace_fortran_parameter(
                    original, parameter, formatted
                )
                value_map[parameter.display_name] = formatted

            suffix = "_".join(f"{name}-{value_map[name].replace('+', '')}" for name in parameter_names)
            path = root / f"{source.stem}_{index:04d}_{suffix}{source.suffix}"
            path.write_text("\n".join(variant_lines) + "\n", encoding="utf-8")
            generated.append((path, value_map))

        self._log(f"已生成 {len(generated)} 个 Fortran 子程序：{root}")
        return generated

    def _generate_case_files(self) -> list[tuple[Path, Path, dict[str, str]]]:
        try:
            fortran_selected = self._selected_sweep_values()
            inp_selected = self._selected_inp_sweep_values()
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return []

        try:
            fortran_text = self.fortran_path.get().strip().strip('"')
            fortran_source = Path(fortran_text) if fortran_text else None
            inp_source = Path(self.inp_path.get().strip().strip('"'))
            if fortran_selected and fortran_source is None:
                raise ValueError("已选择 Fortran 扫描参数，但未提供 Fortran 文件。")
            if fortran_source is not None:
                if not fortran_source.exists():
                    raise ValueError("Fortran 子程序文件不存在。")
                fortran_lines = fortran_source.read_text(encoding="utf-8", errors="replace").splitlines()
            else:
                fortran_lines = []
            inp_lines = inp_source.read_text(encoding="utf-8", errors="replace").splitlines()
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return []

        fortran_axes = fortran_selected or [(None, [None])]  # type: ignore[list-item]
        inp_axes = inp_selected or [(None, [None])]  # type: ignore[list-item]
        case_root = Path(self.output_dir.get().strip().strip('"')) / f"{inp_source.stem}_cases"
        case_root.mkdir(parents=True, exist_ok=True)
        generated: list[tuple[Path, Path, dict[str, str]]] = []

        all_axes = fortran_axes + inp_axes
        for index, combination in enumerate(itertools.product(*[axis[1] for axis in all_axes]), start=1):
            case_dir = case_root / f"case_{index:04d}"
            case_dir.mkdir(parents=True, exist_ok=True)
            value_map: dict[str, str] = {}
            variant_fortran = list(fortran_lines)
            variant_inp = list(inp_lines)

            for (parameter, _), value in zip(all_axes, combination):
                if parameter is None or value is None:
                    continue
                if isinstance(parameter, FortranParameter):
                    formatted = self._format_fortran_decimal(value)
                    original = variant_fortran[parameter.line_index]
                    variant_fortran[parameter.line_index] = self._replace_fortran_parameter(
                        original, parameter, formatted
                    )
                    value_map[parameter.display_name] = formatted
                else:
                    value_map[parameter.key] = self._format_inp_parameter_value(parameter.key, value)

            inp_values = {
                key: value
                for key, value in value_map.items()
                if self._base_inp_key(key)
                in {
                    "TEMP0",
                    "STEP_TIME",
                    "AMP3_END_TIME",
                    "DISP_Y",
                    "DEPVAR",
                    "DENSITY",
                    "ELASTIC_E",
                    "ELASTIC_NU",
                    "CONDUCTIVITY",
                    "SPECIFIC_HEAT",
                }
            }
            variant_inp = self._replace_inp_parameters(variant_inp, inp_values)

            fortran_path = case_dir / fortran_source.name if fortran_source is not None else None
            inp_path = case_dir / inp_source.name
            if fortran_path is not None:
                fortran_path.write_text("\n".join(variant_fortran) + "\n", encoding="utf-8")
            inp_path.write_text("\n".join(variant_inp) + "\n", encoding="utf-8")
            (case_dir / "case_parameters.json").write_text(
                json.dumps(value_map, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            generated.append((fortran_path, inp_path, value_map))

        if fortran_selected or inp_selected:
            self._log(f"已生成 {len(generated)} 个批量工况：{case_root}")
        else:
            self._log(f"未选择扫描参数，已按当前文件生成 1 个工况：{case_root}")
        return generated

    def _build_command(
        self,
        fortran_override: Path | None = None,
        job_override: str | None = None,
        inp_override: Path | None = None,
    ) -> tuple[list[str], Path, Path]:
        fortran_text = self.fortran_path.get().strip().strip('"')
        fortran = fortran_override or (Path(fortran_text) if fortran_text else None)
        inp = inp_override or Path(self.inp_path.get().strip().strip('"'))
        output_root = Path(self.output_dir.get().strip().strip('"'))
        job = job_override or self.job_name.get().strip()
        cpus = self.cpus.get().strip()

        if fortran is not None:
            if not fortran.exists():
                raise ValueError("Fortran 子程序文件不存在。")
            if fortran.suffix.lower() not in FORTRAN_EXTS:
                raise ValueError("Fortran 文件后缀应为 .for/.f/.f90/.f95/.f77。")
        if not inp.exists():
            raise ValueError("inp 文件不存在。")
        if inp.suffix.lower() not in INP_EXTS:
            raise ValueError("inp 文件后缀应为 .inp。")
        if not job:
            raise ValueError("Job 名称不能为空。")
        if not cpus.isdigit() or int(cpus) < 1:
            raise ValueError("CPU 核数必须是大于 0 的整数。")

        run_dir = output_root / f"{job}_{time.strftime('%Y%m%d_%H%M%S')}"
        abaqus_command = self.abaqus_cmd.get().strip().strip('"') or "abaqus"
        command = [
            abaqus_command,
            f"job={job}",
            f"input={inp}",
            f"cpus={int(cpus)}",
        ]
        if fortran is not None:
            command.insert(3, f"user={fortran}")

        double_value = self._double_value()
        if double_value:
            command.append(f"double={double_value}")

        mode = self.run_mode.get().strip()
        if mode:
            command.append(mode)

        extra = self.extra_args.get().strip()
        if extra:
            command.extend(extra.split())

        return command, run_dir, run_dir / "abaqus_runner.log"

    def _double_value(self) -> str:
        text = self.precision.get()
        mapping = {
            "默认": "",
            "单精度/off": "off",
            "显式双精度/explicit": "explicit",
            "约束双精度/constraint": "constraint",
            "全部双精度/both": "both",
        }
        return mapping.get(text, "")

    def _refresh_command_preview(self) -> None:
        try:
            command, run_dir, _ = self._build_command()
            text = "工作目录：{}\n命令：{}".format(run_dir, self._format_command(command))
        except Exception as exc:
            text = f"配置未完整：{exc}"
        self.command_text.configure(state="normal")
        self.command_text.delete("1.0", END)
        self.command_text.insert(END, text)
        self.command_text.configure(state="disabled")

    def _format_command(self, command: list[str]) -> str:
        return " ".join(f'"{part}"' if " " in part else part for part in command)

    def _run_abaqus(self) -> None:
        if self.process and self.process.poll() is None:
            messagebox.showinfo(APP_TITLE, "已有 Abaqus 任务正在运行。")
            return

        try:
            command, run_dir, log_path = self._build_command()
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        preview = f"将在以下文件夹运行：\n{run_dir}\n\n命令：\n{self._format_command(command)}"
        if self.ask_before_run.get() and not messagebox.askyesno(APP_TITLE, preview):
            return

        self._save_config()
        run_dir.mkdir(parents=True, exist_ok=True)
        self._log("\n" + "=" * 70)
        self._log(f"开始运行：{self._format_command(command)}")
        self._log(f"工作目录：{run_dir}")
        self._log(f"日志文件：{log_path}")
        self.status.set("Abaqus 运行中...")

        thread = threading.Thread(target=self._worker_run, args=(command, run_dir, log_path), daemon=True)
        thread.start()

    def _run_sweep(self) -> None:
        generated = self._generate_sweep_files()
        if not generated:
            return
        if self.process and self.process.poll() is None:
            messagebox.showinfo(APP_TITLE, "已有 Abaqus 任务正在运行。")
            return

        try:
            _, base_run_dir, _ = self._build_command()
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        preview = (
            f"将依次运行 {len(generated)} 个子程序。\n"
            f"结果目录：{base_run_dir.parent}\n\n"
            "每个组合会使用独立 job 名和独立结果文件夹。"
        )
        if self.ask_before_run.get() and not messagebox.askyesno(APP_TITLE, preview):
            return

        self._save_config()
        thread = threading.Thread(target=self._worker_run_sweep, args=(generated,), daemon=True)
        thread.start()

    def _worker_run_sweep(self, generated: list[tuple[Path, dict[str, str]]]) -> None:
        original_job = self.job_name.get()
        try:
            total_started = time.perf_counter()
            total = len(generated)
            for index, (fortran_file, value_map) in enumerate(generated, start=1):
                started = time.perf_counter()
                suffix = "_".join(f"{name}{value.replace('+', '')}" for name, value in value_map.items())
                command, run_dir, log_path = self._build_command(
                    fortran_override=fortran_file,
                    job_override=f"{original_job}_{index:04d}",
                )
                run_dir.mkdir(parents=True, exist_ok=True)
                self.log_queue.put("\n" + "=" * 70)
                self.log_queue.put(f"批量任务 {index}/{total}：{suffix}")
                self.log_queue.put(f"开始运行：{self._format_command(command)}")
                self.log_queue.put(f"工作目录：{run_dir}")
                with log_path.open("w", encoding="utf-8", errors="replace") as log_file:
                    self.process = subprocess.Popen(
                        command,
                        cwd=run_dir,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True,
                        encoding="utf-8",
                        errors="replace",
                        env=os.environ.copy(),
                    )
                    assert self.process.stdout is not None
                    for line in self.process.stdout:
                        log_file.write(line)
                        log_file.flush()
                        self.log_queue.put(line.rstrip("\n"))
                    code = self.process.wait()
                self.log_queue.put(
                    f"批量任务 {index}/{total} 完成，退出码：{code}，耗时：{self._format_duration(time.perf_counter() - started)}"
                )
                if code != 0:
                    self.log_queue.put("__STATUS__批量运行中断")
                    return
                self._auto_export_odb_after_run(run_dir, command)
            self.log_queue.put(f"批量运行总耗时：{self._format_duration(time.perf_counter() - total_started)}")
            self.log_queue.put("__STATUS__批量运行完成")
        except FileNotFoundError:
            self.log_queue.put("找不到 Abaqus 命令。请检查“Abaqus 命令”是否在 PATH 中，或填入完整路径。")
            self.log_queue.put("__STATUS__命令不存在")
        except Exception as exc:
            self.log_queue.put(f"批量运行失败：{exc}")
            self.log_queue.put("__STATUS__批量运行失败")
        finally:
            self.process = None

    def _run_cases(self) -> None:
        generated = self._generate_case_files()
        if not generated:
            return
        if self.process and self.process.poll() is None:
            messagebox.showinfo(APP_TITLE, "已有 Abaqus 任务正在运行。")
            return
        preview = f"将依次运行 {len(generated)} 个联合工况。"
        if self.ask_before_run.get() and not messagebox.askyesno(APP_TITLE, preview):
            return
        self._save_config()
        thread = threading.Thread(target=self._worker_run_cases, args=(generated,), daemon=True)
        thread.start()

    def _format_duration(self, seconds: float) -> str:
        seconds_int = int(round(seconds))
        hours, remainder = divmod(seconds_int, 3600)
        minutes, secs = divmod(remainder, 60)
        if hours:
            return f"{hours}小时{minutes}分{secs}秒"
        if minutes:
            return f"{minutes}分{secs}秒"
        return f"{secs}秒"

    def _parse_odb_variables(self) -> list[str]:
        raw = self.odb_variable.get().strip().upper()
        variables = [item for item in re.split(r"[,，;；\s]+", raw) if item]
        unique: list[str] = []
        for variable in variables:
            if variable not in unique:
                unique.append(variable)
        return unique

    def _build_odb_export_requests(
        self,
        odb_path: Path,
        output_root: Path,
    ) -> list[tuple[list[str], Path, Path, str, str, str, str]]:
        if not odb_path.exists() or odb_path.suffix.lower() != ".odb":
            raise ValueError(f"找不到有效的 odb 文件：{odb_path}")
        step = self.odb_step.get().strip()
        instance = self.odb_instance.get().strip()
        element = self.odb_element.get().strip()
        integration_point = self.odb_integration_point.get().strip()
        variables = self._parse_odb_variables()
        if not step or not instance or not element or not integration_point or not variables:
            raise ValueError("Step、Instance、单元号、积分点和变量都不能为空。")
        if not element.isdigit() or not integration_point.isdigit():
            raise ValueError("单元号和积分点必须是整数。")
        output_root.mkdir(parents=True, exist_ok=True)
        script_path = Path(__file__).with_name("odb_extract_xy.py")
        requests: list[tuple[list[str], Path, Path, str, str, str, str]] = []
        for variable in variables:
            stem = f"{odb_path.stem}_{instance}_E{element}_IP{integration_point}_{variable}"
            csv_path = output_root / f"{stem}.csv"
            svg_path = output_root / f"{stem}.svg"
            command = [
                self.abaqus_cmd.get().strip().strip('"') or "abaqus",
                "python",
                str(script_path),
                str(odb_path),
                step,
                instance,
                element,
                integration_point,
                variable,
                str(csv_path),
            ]
            requests.append((command, csv_path, svg_path, variable, instance, element, integration_point))
        return requests

    def _job_name_from_command(self, command: list[str]) -> str:
        for item in command:
            if item.lower().startswith("job="):
                return item.split("=", 1)[1]
        return self.job_name.get().strip() or "Job-1"

    def _auto_export_odb_after_run(self, run_dir: Path, command: list[str]) -> None:
        if not self.auto_export_odb.get():
            return
        job = self._job_name_from_command(command)
        odb_path = run_dir / f"{job}.odb"
        self.log_queue.put(f"自动导出曲线：准备读取 {odb_path}")
        try:
            requests = self._build_odb_export_requests(odb_path, run_dir / "odb_curves")
            self._run_odb_export_batch_sync(requests, self.keep_curve_csv.get())
        except Exception as exc:
            self.log_queue.put(f"自动导出 ODB 曲线失败：{exc}")

    def _export_odb_curve(self) -> None:
        if self.process and self.process.poll() is None:
            messagebox.showinfo(APP_TITLE, "已有任务正在运行。")
            return

        try:
            odb_path = Path(self.odb_path.get().strip().strip('"'))
            requests = self._build_odb_export_requests(
                odb_path,
                Path(self.output_dir.get().strip().strip('"')) / "odb_curves",
            )
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        self._save_config()
        self.status.set("正在导出 ODB 曲线...")
        self._log("\n" + "=" * 70)
        self._log(f"准备导出 {len(requests)} 张 ODB 曲线图。")
        thread = threading.Thread(
            target=self._worker_export_odb_curve,
            args=(requests, self.keep_curve_csv.get()),
            daemon=True,
        )
        thread.start()

    def _worker_export_odb_curve(
        self,
        requests: list[tuple[list[str], Path, Path, str, str, str, str]],
        keep_csv: bool,
    ) -> None:
        try:
            self._run_odb_export_batch_sync(requests, keep_csv)
            self.log_queue.put("__STATUS__ODB 曲线导出完成")
        except FileNotFoundError as exc:
            self.log_queue.put(f"导出所需文件不存在：{exc}")
            self.log_queue.put("__STATUS__命令不存在")
        except Exception as exc:
            self.log_queue.put(f"ODB 曲线导出失败：{exc}")
            self.log_queue.put("__STATUS__ODB 曲线导出失败")
        finally:
            self.process = None

    def _run_odb_export_batch_sync(
        self,
        requests: list[tuple[list[str], Path, Path, str, str, str, str]],
        keep_csv: bool,
    ) -> None:
        started = time.perf_counter()
        total = len(requests)
        for index, request in enumerate(requests, start=1):
            command, csv_path, svg_path, variable, instance, element, integration_point = request
            self.log_queue.put(f"ODB 曲线 {index}/{total}：{variable}")
            self._run_odb_export_sync(
                command,
                csv_path,
                svg_path,
                variable,
                instance,
                element,
                integration_point,
                keep_csv,
            )
        if total > 1:
            self.log_queue.put(f"ODB 曲线批量导出耗时：{self._format_duration(time.perf_counter() - started)}")

    def _run_odb_export_sync(
        self,
        command: list[str],
        csv_path: Path,
        svg_path: Path,
        variable: str,
        instance: str,
        element: str,
        integration_point: str,
        keep_csv: bool,
    ) -> None:
        started = time.perf_counter()
        self.log_queue.put(f"开始导出 ODB 曲线：{self._format_command(command)}")
        self.process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=os.environ.copy(),
        )
        assert self.process.stdout is not None
        for line in self.process.stdout:
            self.log_queue.put(line.rstrip("\n"))
        code = self.process.wait()
        if code != 0:
            raise RuntimeError(f"ODB 曲线导出失败，退出码：{code}")
        if not csv_path.exists():
            raise RuntimeError("Abaqus Python 没有生成 CSV，请先查看上面的提取报错。")
        rows = self._read_curve_csv(csv_path)
        self._write_svg_plot(svg_path, rows, variable, instance, element, integration_point)
        if keep_csv:
            self.log_queue.put(f"已导出 CSV：{csv_path}")
        else:
            csv_path.unlink(missing_ok=True)
            self.log_queue.put("未保留 CSV 数据，只导出曲线图。")
        self.log_queue.put(f"已导出曲线图：{svg_path}")
        self.log_queue.put(f"ODB 曲线导出耗时：{self._format_duration(time.perf_counter() - started)}")

    def _read_curve_csv(self, csv_path: Path) -> list[tuple[float, float]]:
        rows: list[tuple[float, float]] = []
        with csv_path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.reader(handle)
            next(reader, None)
            for row in reader:
                if len(row) >= 2:
                    rows.append((float(row[0]), float(row[1])))
        if not rows:
            raise ValueError("CSV 中没有可绘制的数据。")
        return rows

    def _write_svg_plot(
        self,
        svg_path: Path,
        rows: list[tuple[float, float]],
        variable: str,
        instance: str,
        element: str,
        integration_point: str,
    ) -> None:
        width, height = 960, 600
        left, right, top, bottom = 90, 30, 40, 80
        xs = [row[0] for row in rows]
        ys = [row[1] for row in rows]
        xmin, xmax = min(xs), max(xs)
        ymin, ymax = min(ys), max(ys)
        if xmin == xmax:
            xmax = xmin + 1.0
        if ymin == ymax:
            ymax = ymin + 1.0

        def sx(value: float) -> float:
            return left + (value - xmin) / (xmax - xmin) * (width - left - right)

        def sy(value: float) -> float:
            return height - bottom - (value - ymin) / (ymax - ymin) * (height - top - bottom)

        points = " ".join(f"{sx(x):.2f},{sy(y):.2f}" for x, y in rows)
        title = f"{variable}  PI: {instance}  E:{element}  IP:{integration_point}"
        parts = [
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
            '<rect width="100%" height="100%" fill="#f3f3f3"/>',
            f'<text x="{width / 2}" y="24" text-anchor="middle" font-size="18">{escape(title)}</text>',
            f'<line x1="{left}" y1="{height - bottom}" x2="{width - right}" y2="{height - bottom}" stroke="#333"/>',
            f'<line x1="{left}" y1="{top}" x2="{left}" y2="{height - bottom}" stroke="#333"/>',
        ]
        for index in range(6):
            ratio = index / 5
            x_value = xmin + (xmax - xmin) * ratio
            x_coord = sx(x_value)
            parts.append(f'<line x1="{x_coord:.2f}" y1="{height - bottom}" x2="{x_coord:.2f}" y2="{height - bottom + 6}" stroke="#333"/>')
            parts.append(f'<text x="{x_coord:.2f}" y="{height - bottom + 26}" text-anchor="middle" font-size="12">{x_value:.4g}</text>')
            y_value = ymin + (ymax - ymin) * ratio
            y_coord = sy(y_value)
            parts.append(f'<line x1="{left - 6}" y1="{y_coord:.2f}" x2="{left}" y2="{y_coord:.2f}" stroke="#333"/>')
            parts.append(f'<text x="{left - 12}" y="{y_coord + 4:.2f}" text-anchor="end" font-size="12">{y_value:.4g}</text>')
        parts.extend(
            [
                f'<polyline fill="none" stroke="#d9534f" stroke-width="2" points="{points}"/>',
                f'<text x="{width / 2}" y="{height - 24}" text-anchor="middle" font-size="14">Time</text>',
                f'<text x="22" y="{height / 2}" text-anchor="middle" font-size="14" transform="rotate(-90 22 {height / 2})">{escape(variable)}</text>',
                "</svg>",
            ]
        )
        svg_path.write_text("\n".join(parts), encoding="utf-8")

    def _worker_run_cases(self, generated: list[tuple[Path | None, Path, dict[str, str]]]) -> None:
        original_job = self.job_name.get()
        try:
            total_started = time.perf_counter()
            total = len(generated)
            for index, (fortran_file, inp_file, value_map) in enumerate(generated, start=1):
                started = time.perf_counter()
                command, run_dir, log_path = self._build_command(
                    fortran_override=fortran_file,
                    inp_override=inp_file,
                    job_override=f"{original_job}_{index:04d}",
                )
                run_dir.mkdir(parents=True, exist_ok=True)
                self.log_queue.put("\n" + "=" * 70)
                self.log_queue.put(f"联合工况 {index}/{total}：{value_map}")
                self.log_queue.put(f"开始运行：{self._format_command(command)}")
                self.log_queue.put(f"工作目录：{run_dir}")
                with log_path.open("w", encoding="utf-8", errors="replace") as log_file:
                    self.process = subprocess.Popen(
                        command,
                        cwd=run_dir,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True,
                        encoding="utf-8",
                        errors="replace",
                        env=os.environ.copy(),
                    )
                    assert self.process.stdout is not None
                    for line in self.process.stdout:
                        log_file.write(line)
                        log_file.flush()
                        self.log_queue.put(line.rstrip("\n"))
                    code = self.process.wait()
                self.log_queue.put(
                    f"联合工况 {index}/{total} 完成，退出码：{code}，耗时：{self._format_duration(time.perf_counter() - started)}"
                )
                if code != 0:
                    self.log_queue.put("__STATUS__联合工况运行中断")
                    return
                self._auto_export_odb_after_run(run_dir, command)
            self.log_queue.put(f"联合工况总耗时：{self._format_duration(time.perf_counter() - total_started)}")
            self.log_queue.put("__STATUS__联合工况运行完成")
        except FileNotFoundError:
            self.log_queue.put("找不到 Abaqus 命令。请检查“Abaqus 命令”是否在 PATH 中，或填入完整路径。")
            self.log_queue.put("__STATUS__命令不存在")
        except Exception as exc:
            self.log_queue.put(f"联合工况运行失败：{exc}")
            self.log_queue.put("__STATUS__联合工况运行失败")
        finally:
            self.process = None

    def _worker_run(self, command: list[str], run_dir: Path, log_path: Path) -> None:
        try:
            started = time.perf_counter()
            env = os.environ.copy()
            with log_path.open("w", encoding="utf-8", errors="replace") as log_file:
                self.process = subprocess.Popen(
                    command,
                    cwd=run_dir,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    env=env,
                )
                assert self.process.stdout is not None
                for line in self.process.stdout:
                    log_file.write(line)
                    log_file.flush()
                    self.log_queue.put(line.rstrip("\n"))
                code = self.process.wait()
            duration = self._format_duration(time.perf_counter() - started)
            self.log_queue.put(f"任务结束，退出码：{code}，耗时：{duration}")
            if code == 0:
                self._auto_export_odb_after_run(run_dir, command)
                self.log_queue.put(f"本次计算耗时：{duration}")
                self.log_queue.put("__STATUS__运行完成")
            else:
                self.log_queue.put("__STATUS__运行结束但 Abaqus 返回错误")
        except FileNotFoundError:
            self.log_queue.put("找不到 Abaqus 命令。请检查“Abaqus 命令”是否在 PATH 中，或填入完整路径。")
            self.log_queue.put("__STATUS__命令不存在")
        except Exception as exc:
            self.log_queue.put(f"运行失败：{exc}")
            self.log_queue.put("__STATUS__运行失败")
        finally:
            self.process = None

    def _stop_process(self) -> None:
        if not self.process or self.process.poll() is not None:
            self._log("当前没有正在运行的任务。")
            return
        self.process.terminate()
        self._log("已发送停止信号。")
        self.status.set("正在停止...")

    def _open_output_dir(self) -> None:
        try:
            path_text = self.output_dir.get().strip().strip('"')
            if not path_text:
                raise ValueError("结果输出文件夹不能为空。")
            path = Path(path_text)
            path.mkdir(parents=True, exist_ok=True)
            os.startfile(path)
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"无法打开结果输出文件夹：\n{exc}")

    def _poll_log_queue(self) -> None:
        while True:
            try:
                item = self.log_queue.get_nowait()
            except queue.Empty:
                break
            if item.startswith("__STATUS__"):
                status = item.replace("__STATUS__", "", 1)
                self.status.set(status)
                self._notify_status(status)
            else:
                self._log(item)
        self.root.after(200, self._poll_log_queue)

    def _log(self, text: str) -> None:
        self.log_text.insert(END, text + "\n")
        self.log_text.see(END)

    def _notify_status(self, status: str) -> None:
        notify_keywords = ("完成", "失败", "中断", "错误", "不存在")
        if not any(keyword in status for keyword in notify_keywords):
            return
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.attributes("-topmost", True)
            self.root.after(1500, lambda: self.root.attributes("-topmost", False))
            if any(keyword in status for keyword in ("失败", "中断", "错误", "不存在")):
                messagebox.showerror(APP_TITLE, status, parent=self.root)
            else:
                messagebox.showinfo(APP_TITLE, status, parent=self.root)
        except Exception:
            pass

    def _on_close(self) -> None:
        self._save_config()
        self.root.destroy()


def main() -> None:
    root = Tk()
    app = AbaqusRunnerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
