@echo off
setlocal
cd /d "%~dp0"

echo Starting Abaqus Param Runner 1.4.15...
echo.

where python >nul 2>nul
if %errorlevel%==0 (
    python "%~dp0abaqus_param_runner.py"
    goto finished
)

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 "%~dp0abaqus_param_runner.py"
    goto finished
)

echo Python was not found.
echo Please install Python 3 or add Python to PATH.

:finished
echo.
echo Program closed. If there was an error, copy the text above.
pause
