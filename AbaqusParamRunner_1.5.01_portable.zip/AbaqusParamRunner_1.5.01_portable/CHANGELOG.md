# Abaqus Param Runner Changelog

## 1.5.01 - 2026-06-17

- Added an option to open the last generated ODB file after successful runs.
- Moved Abaqus command selection out of the always-visible settings area.
- Delayed Abaqus command auto-detection until the first run/export action, with manual selection only when auto-detection fails.
- Enlarged the main action buttons and file-row buttons.
- Show automatic SVG curve export settings only when SVG export is enabled.
- Renamed SVG/CSV export options with more formal wording.
- Open post-run ODB files through Abaqus Viewer instead of relying on Windows file associations.

## 1.4.15 - 2026-06-05

- Cleaned trailing decimal dots from inp parameter display values.
- Stopped adding trailing decimal dots when writing integer-valued inp sweep values.

## 1.4.14 - 2026-06-04

- Allowed manual Instance entry even when inp contains only one Instance.
- Added an Open button beside the result output folder.
- Added visible output-folder opening errors.

## 1.4.13 - 2026-06-03

- Added selectable Instance list read from inp files.
- Added selectable ODB variable list read from inp `*Element Output`.
- Expanded `SDV` into `SDV1..SDVn` using inp `*Depvar`.

## 1.4.12 - 2026-06-03

- Added Instance reading from inp files.
- Added buttons to fill Instance in automatic and manual ODB export settings.
- Added multi-variable ODB export, generating one SVG per variable.

## 1.4.11 - 2026-06-03

- Distinguished inp material parameters by material name.
- Limited material parameter replacement to the selected material block.
- Added scrolling to the inp parameter window.

## 1.4.10 - 2026-06-02

- Fixed Job name auto-updating after choosing a new Fortran file.
- Kept saved Job names on startup without treating them as permanent manual edits.

## 1.4.9 - 2026-05-29

- Added elapsed-time logging for Abaqus runs.
- Added inp detection/replacement for density, elastic constants, conductivity, and specific heat.
- Added automatic post-run ODB SVG curve export with optional CSV retention.

## 1.4.8 - 2026-05-26

- Fixed the window title version text that still showed 1.4.6.
- Added inp `*Depvar` detection and integer replacement for batch cases.

## 1.4.7 - 2026-05-22

- Default Job names from the selected Fortran file stem while preserving user edits.

## 1.4.6 - 2026-05-21

- Added topmost completion/failure popups for long-running tasks.

## 1.4.5 - 2026-05-18

- Added support for Fortran `PARAMETER (...)` constants.
- Added scoped Fortran parameter labels for repeated names across subprograms.

## 1.4.4 - 2026-05-18

- Added inp-only workflows without requiring a Fortran user subroutine.
- Omit `user=` from the Abaqus command when no subroutine is supplied.

## 1.4.3 - 2026-05-18

- Allowed the batch-run workflow to execute one current-file case when no sweep parameters are selected.

## 1.4.2 - 2026-05-18

- Improved ODB SDV extraction compatibility.
- Added diagnostic output for available fields, instances, and integration points.
- Fixed misleading missing-command text after ODB extraction failures.

## 1.4.1 - 2026-05-18

- Added descending sweep support.
- Fixed misleading no-parameter-selected errors for invalid sweep ranges.

## 1.4.0 - 2026-05-18

- Added ODB field-output curve export.
- Added Abaqus Python extraction for exact instance / element / integration-point curves.
- Added CSV and SVG outputs for result checking.

## 1.3.2 - 2026-05-18

- Removed the old `批量运行` and `运行 Abaqus` toolbar actions.
- Renamed the remaining batch action to `运行批量工况`.

## 1.3.1 - 2026-05-18

- Moved batch case generation into both parameter dialogs.
- Renamed the dialog action to `生成批量工况`.
- Removed duplicate generation buttons from the main toolbar.

## v3 - 2026-05-15

- Added inp parameter detection for initial temperature, step time, Amp-3 end time, and displacement magnitude.
- Added combined Fortran + inp case generation.
- Added per-case parameter manifests and combined batch execution.

## v2 - 2026-05-15

- Added Fortran parameter detection from the initialization block.
- Added parameter selection with start, end, and step controls.
- Added automatic Fortran variant generation.
- Added sequential batch execution for generated variants.

## v1 - 2026-05-15

- Added the first Tkinter GUI version.
- Added Fortran and inp file selection.
- Added Abaqus command configuration.
- Added CPU count and precision options.
- Added command preview.
- Added Abaqus process runner and run log saving.
- Added robust `run.bat` and `run_debug.bat` launchers.
