@echo off
cd /d "%~dp0versions\v1.5.01"
call run.bat
