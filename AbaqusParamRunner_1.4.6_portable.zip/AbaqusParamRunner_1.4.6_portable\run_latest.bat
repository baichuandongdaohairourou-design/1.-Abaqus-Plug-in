@echo off
cd /d "%~dp0versions\v1.4.6"
call run.bat
