# Abaqus Param Runner 1.4.6

这个版本使用批量工况流程：

- 选择或粘贴 Fortran 子程序文件：`.for/.f/.f90/.f95/.f77`
- 选择或粘贴 Abaqus `.inp` 文件
- 设置 Abaqus 命令、job 名、CPU 核数、精度、运行方式和额外参数
- 预览命令行
- 调用 Abaqus 运行，并把输出保存到独立结果文件夹
- 保存运行日志：`abaqus_runner.log`
- 自动识别 Fortran 初始化区中的数值参数
- 勾选参数并设置起点、终点、步长
- 按参数组合自动生成多个批量工况
- 顺序批量运行全部工况
- 自动识别 inp 中的初始温度、分析时间、Amp-3 完成时间和位移幅值
- 自动生成 `.for + .inp` 成对工况
- 每个工况保存 `case_parameters.json`
- 按实例、单元、积分点和变量导出 ODB 曲线
- 输出 `CSV + SVG`，便于和 Abaqus CAE 曲线直接核对

## 启动

在当前目录运行：

```powershell
python .\abaqus_param_runner.py
```

## 命令格式

程序会生成类似这样的命令：

```powershell
abaqus job=job_001 input=D:\case\model.inp user=D:\case\sub.for cpus=4 interactive
```

如果选择双精度，会追加 Abaqus 的 `double=` 参数，例如：

```powershell
abaqus job=job_001 input=D:\case\model.inp user=D:\case\sub.for cpus=4 double=both interactive
```

## 说明

- “单精度/off”会生成 `double=off`。
- “默认”不会传入 `double=` 参数，让 Abaqus 使用当前默认设置。
- 如果你的 Abaqus 命令不在 PATH 里，可以把“Abaqus 命令”改成完整路径，或者改成你环境里的启动命令。
- 拖拽文件依赖本机 Tk 是否带 `tkdnd`。如果不可用，仍然可以使用“选择”和“粘贴路径”。
- 如果提示找不到 Abaqus 命令，在软件里点击“选择命令”，选择 Abaqus 安装目录里的 `abaqus.bat`、`abq2024.bat` 或类似启动脚本。
- 软件会自动保存上次设置，下次打开会自动恢复 Abaqus 命令、文件路径、输出目录、CPU 核数和精度。
- 参数识别当前只读取 `DOUBLE PRECISION` 声明过、并且位于初始化区的纯数值赋值。
- 勾选多个参数时，会生成这些参数值的全部组合。
- 参数范围支持递增和递减，例如 `1e6 -> 5e6` 或 `6e6 -> 5e6`。
- 如果没有勾选任何参数，`运行批量工况` 会直接按当前 `.for + .inp` 生成并运行 1 个工况。
- 如果不需要用户子程序，可以留空 Fortran 文件，只修改并运行 inp 工况。
- Fortran 参数识别支持普通赋值和 `PARAMETER (...)` 常量。
- 同名参数会带所属子程序名显示，例如 `DRX_UPDATE_POINT.B_ALPHA`。
- 批量运行或 ODB 导出完成、失败或中断时会弹窗提醒。
- inp 参数识别当前支持 `TEMP0`、`STEP_TIME`、`AMP3_END_TIME`、`DISP_Y`。
- ODB 曲线导出当前支持标量场变量，以及 `SDV1`、`SDV2` 这类单个状态变量分量。
- 如果导出失败，日志会列出可用场变量、实例名和该单元实际存在的积分点，便于核对输入。

## 下一版建议

- 扫描 Fortran 变量并提供范围/补偿设置。
- 按变量组合自动生成多个 Fortran 子程序。
- 批量生成并运行多个 Abaqus job。
- 调用 Abaqus Python 从 `.odb` 提取 SDV 随时间变化数据。
- 输出曲线图和参数-结果对比表。
