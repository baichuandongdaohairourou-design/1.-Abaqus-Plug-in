from __future__ import print_function

import csv
import re
import sys

from odbAccess import openOdb


def scalar_value(value, variable, field_key):
    match = re.match(r"^SDV(\d+)$", variable.upper())
    if match and field_key.upper() == "SDV":
        index = int(match.group(1)) - 1
        if index < 0 or index >= len(value.data):
            raise ValueError("Requested SDV component is outside the stored data range.")
        return value.data[index]
    if hasattr(value.data, "__len__"):
        if len(value.data) != 1:
            raise ValueError("Variable is not scalar. Use SDVn or a scalar field variable.")
        return value.data[0]
    return value.data


def main(argv):
    if len(argv) != 8:
        raise SystemExit(
            "usage: odb_extract_xy.py odb_path step_name instance_name "
            "element_label integration_point variable csv_path"
        )

    odb_path, step_name, instance_name, element_label, ip_number, variable, csv_path = argv[1:]
    element_label = int(element_label)
    ip_number = int(ip_number)
    variable_upper = variable.upper()
    odb = openOdb(path=odb_path, readOnly=True)
    try:
        if step_name not in odb.steps:
            raise ValueError("Step not found: %s" % step_name)
        step = odb.steps[step_name]

        rows = []
        available_field_keys = set()
        available_instances = set()
        matching_element_ips = set()
        for frame in step.frames:
            available_field_keys.update(frame.fieldOutputs.keys())
            if variable_upper in frame.fieldOutputs:
                field_key = variable_upper
            elif re.match(r"^SDV\d+$", variable_upper) and "SDV" in frame.fieldOutputs:
                field_key = "SDV"
            else:
                continue
            field = frame.fieldOutputs[field_key]
            candidates = []
            for value in field.values:
                available_instances.add(value.instance.name)
                if value.instance.name == instance_name and value.elementLabel == element_label:
                    matching_element_ips.add(getattr(value, "integrationPoint", None))
                if (
                    value.instance.name == instance_name
                    and value.elementLabel == element_label
                    and getattr(value, "integrationPoint", None) == ip_number
                ):
                    candidates.append(value)
            if not candidates:
                continue
            rows.append((frame.frameValue, scalar_value(candidates[0], variable_upper, field_key)))

        if not rows:
            raise ValueError(
                "No matching field values were found. "
                "Available fields: %s. Available instances: %s. "
                "Integration points for %s E:%s: %s."
                % (
                    ", ".join(sorted(available_field_keys)),
                    ", ".join(sorted(available_instances)),
                    instance_name,
                    element_label,
                    ", ".join(str(item) for item in sorted(matching_element_ips) if item is not None),
                )
            )

        with open(csv_path, "w", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(["time", variable_upper])
            writer.writerows(rows)
        print("WROTE", csv_path)
        print("POINTS", len(rows))
    finally:
        odb.close()


if __name__ == "__main__":
    main(sys.argv)
