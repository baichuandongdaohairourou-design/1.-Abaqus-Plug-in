# Abaqus Param Runner Changelog

## 1.4.11 - 2026-06-03

- Distinguished inp material parameters by material name.
- Limited material parameter replacement to the selected material block.
- Added scrolling to the inp parameter window.

## 1.4.10 - 2026-06-02

- Fixed Job name auto-updating after choosing a new Fortran file.
- Kept saved Job names on startup without treating them as permanent manual edits.

## 1.4.9 - 2026-05-29

- Added elapsed-time logging for Abaqus runs.
- Added inp detection/replacement for density, elastic constants, conductivity, and specific heat.
- Added automatic post-run ODB SVG curve export with optional CSV retention.

## 1.4.8 - 2026-05-26

- Fixed the window title version text that still showed 1.4.6.
- Added inp `*Depvar` detection and integer replacement for batch cases.

## 1.4.7 - 2026-05-22

- Default Job names from the selected Fortran file stem while preserving user edits.

## 1.4.6 - 2026-05-21

- Added topmost completion/failure popups for long-running tasks.

## 1.4.5 - 2026-05-18

- Added support for Fortran `PARAMETER (...)` constants.
- Added scoped Fortran parameter labels for repeated names across subprograms.

## 1.4.4 - 2026-05-18

- Added inp-only workflows without requiring a Fortran user subroutine.
- Omit `user=` from the Abaqus command when no subroutine is supplied.

## 1.4.3 - 2026-05-18

- Allowed the batch-run workflow to execute one current-file case when no sweep parameters are selected.

## 1.4.2 - 2026-05-18

- Improved ODB SDV extraction compatibility.
- Added diagnostic output for available fields, instances, and integration points.
- Fixed misleading missing-command text after ODB extraction failures.

## 1.4.1 - 2026-05-18

- Added descending sweep support.
- Fixed misleading no-parameter-selected errors for invalid sweep ranges.

## 1.4.0 - 2026-05-18

- Added ODB field-output curve export.
- Added Abaqus Python extraction for exact instance / element / integration-point curves.
- Added CSV and SVG outputs for result checking.

## 1.3.2 - 2026-05-18

- Removed the old `批量运行` and `运行 Abaqus` toolbar actions.
- Renamed the remaining batch action to `运行批量工况`.

## 1.3.1 - 2026-05-18

- Moved batch case generation into both parameter dialogs.
- Renamed the dialog action to `生成批量工况`.
- Removed duplicate generation buttons from the main toolbar.

## v3 - 2026-05-15

- Added inp parameter detection for initial temperature, step time, Amp-3 end time, and displacement magnitude.
- Added combined Fortran + inp case generation.
- Added per-case parameter manifests and combined batch execution.

## v2 - 2026-05-15

- Added Fortran parameter detection from the initialization block.
- Added parameter selection with start, end, and step controls.
- Added automatic Fortran variant generation.
- Added sequential batch execution for generated variants.

## v1 - 2026-05-15

- Added the first Tkinter GUI version.
- Added Fortran and inp file selection.
- Added Abaqus command configuration.
- Added CPU count and precision options.
- Added command preview.
- Added Abaqus process runner and run log saving.
- Added robust `run.bat` and `run_debug.bat` launchers.
