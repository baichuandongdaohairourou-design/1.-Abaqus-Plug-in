@echo off
cd /d "%~dp0versions\v1.4.11"
call run.bat
