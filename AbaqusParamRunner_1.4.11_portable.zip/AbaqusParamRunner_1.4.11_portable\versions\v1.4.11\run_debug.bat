@echo off
setlocal
cd /d "%~dp0"

echo Python location:
where python
where py
echo.
echo Python version:
python --version
py -3 --version
echo.
echo Checking program syntax:
python -m py_compile "%~dp0abaqus_param_runner.py"
echo.
echo Starting app:
python "%~dp0abaqus_param_runner.py"
echo.
pause
