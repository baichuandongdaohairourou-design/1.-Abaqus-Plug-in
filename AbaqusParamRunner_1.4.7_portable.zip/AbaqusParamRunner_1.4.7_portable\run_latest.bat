@echo off
cd /d "%~dp0versions\v1.4.7"
call run.bat
